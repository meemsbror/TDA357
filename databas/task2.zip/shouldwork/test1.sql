insert into countries VALUES('Sweden');
