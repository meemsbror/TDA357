insert into countries values ('A');
insert into areas values ('A','B',2);
--countries
begin;
insert into countries values (null);
commit;
--areas
begin;
insert into areas values ('A', null, 2);
commit;
begin;
insert into areas values ('A', 'Gothenburg', null);
commit;
begin;
insert into cities values ('A', 'B', null);
commit;
--persons
begin;
insert into persons values ('A', null, 'Abraham', 'A','B',0);
commit;
begin;
insert into persons values ('A', '19960123-2631', null, 'A','B',0);
commit;
begin;
insert into persons values ('A', '19960123-2631', 'Abraham', null,'B',0);
commit;
begin;
insert into persons values ('A', '19960123-2631', 'Abraham', 'A', null,0);
commit;
begin;
insert into persons values ('A', '19960123-2631', 'Abraham', 'A','B', null);
commit;
