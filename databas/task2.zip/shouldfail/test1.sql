insert into persons values ('Sweden', '19960123-263', 'Frej Karlsson', 'Sweden', 'Gothenburg', 100000);
